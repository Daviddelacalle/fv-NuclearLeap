/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   config.h
 * Author: pato-lt
 *
 * Created on 17 de abril de 2018, 13:44
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <iostream>
#include <SFML/Graphics.hpp>

#define kVel 0.150
#define npcVel 2
#define kGrav 0.002
#define kGravP 0.0002
#define UPDATE_TICK_TIME 1000/60

using namespace std;

#endif /* CONFIG_H */

